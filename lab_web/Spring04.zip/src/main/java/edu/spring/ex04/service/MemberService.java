package edu.spring.ex04.service;

import edu.spring.ex04.domain.MemberVO;

public interface MemberService {

	MemberVO login(MemberVO vo);
}
