package edu.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.spring.service.ProductService;
import edu.spring.service.UserService;
import edu.spring.vo.ProductVO;
import edu.spring.vo.UserVO;

@Controller
@RequestMapping(value = "/user")
public class UserController {
   
   private static final Logger logger = LoggerFactory.getLogger(UserController.class);
   
   @Autowired
   private UserService userService;
   
   @Autowired
   private ProductService service;
   
   
   // 낙찰받아서 장바구니에 들어온 목록(낙찰받았음-구매 가능)
   @RequestMapping(value = "/cart", method = RequestMethod.GET)
   public void cart(HttpSession session, Model model) {
      System.out.println("cartList에옴");
      //List<UserVO> list = userService.read();
      List<ProductVO> list = new ArrayList<ProductVO>();
      /*int code, String category, String name, Date closed_time, String quantity, String seller,
        String buyer, int immediate_price, String detail, int bidders, Date update_time, int start_price,
        int contract_price, String img, int total_quantity, String process*/
      ProductVO vo1 = new ProductVO(1, "fresh", "호주산 오렌지 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/paris.jpg", 4000,"contract",0);
      ProductVO vo2 = new ProductVO(2, "fresh", "호주산 양고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/images.jpg", 0, "contract",0);
      ProductVO vo3 = new ProductVO(3, "fresh", "호주산 소고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/a.jpg", 0, "contract",0);
      ProductVO vo4 = new ProductVO(4, "fresh", "호주산 파인애플 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 29000, "../resources/images/paris.jpg", 0, "contract",0);
      ProductVO vo5 = new ProductVO(5, "fresh", "호주산 파인애플 2kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 50000, 52000, "../resources/images/images.jpg", 0, "contract",0);
      list.add(vo1);
      list.add(vo2);
      list.add(vo3);
      list.add(vo4);
      list.add(vo5);
      model.addAttribute("productList", list);
      
      String userid= (String) session.getAttribute("login_id");
       list = service.selectListByCart(userid);
      List<ProductVO> list1 = service.selectListByCart(userid);
      UserVO vo = userService.read(userid);
      logger.info("cart list:"+list1.size());
      model.addAttribute("cartList", list1);
      model.addAttribute("vo", vo);
      
   }
   
   // 더미데이터사용  네비게이션 추가하고 테스트하고 지우는 용도
   @RequestMapping(value = "/cart1", method = RequestMethod.GET)
   public void cart1(HttpSession session, Model model) {
      System.out.println("cartList에옴");
      //List<UserVO> list = userService.read();
      List<ProductVO> list = new ArrayList<ProductVO>();
      ProductVO vo1 = new ProductVO(1, "fresh", "호주산 오렌지 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/paris.jpg", 0, "contract",0);
      ProductVO vo2 = new ProductVO(2, "fresh", "호주산 양고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/images.jpg", 0, "contract",0);
      ProductVO vo3 = new ProductVO(3, "fresh", "호주산 소고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/a.jpg", 0, "contract",0);
      ProductVO vo4 = new ProductVO(4, "fresh", "호주산 파인애플 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 29000, "../resources/images/paris.jpg", 0, "contract",0);
      ProductVO vo5 = new ProductVO(5, "fresh", "호주산 파인애플 2kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 50000, 52000, "../resources/images/images.jpg", 0, "contract",0);
      list.add(vo1);
      list.add(vo2);
      list.add(vo3);
      list.add(vo4);
      list.add(vo5);
      model.addAttribute("productList", list);
      
      String userid= (String) session.getAttribute("login_id"); 
       
      list = service.selectListByCart(userid);
   
   }
   
   // 더미데이터사용  네비게이션 추가하고 테스트하고 지우는 용도
   @RequestMapping(value = "/cart2", method = RequestMethod.GET)
   public void cart2(HttpSession session, Model model) {
      System.out.println("cartList에옴");
      //List<UserVO> list = userService.read();
      List<ProductVO> list = new ArrayList<ProductVO>();
      ProductVO vo1 = new ProductVO(1, "fresh", "호주산 오렌지 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/paris.jpg", 0, "contract",0);
      ProductVO vo2 = new ProductVO(2, "fresh", "호주산 양고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/images.jpg", 0, "contract",0);
      ProductVO vo3 = new ProductVO(3, "fresh", "호주산 소고기 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 36000, "../resources/images/a.jpg", 0, "contract",0);
      ProductVO vo4 = new ProductVO(4, "fresh", "호주산 파인애플 1kg", null, "1개", "summer", "aaaaa", 0, null, 0, null, 25000, 29000, "../resources/images/paris.jpg", 0, "contract",0);
      //      ProductVO vo5 = new ProductVO(5, "fresh", "호주산 파인애플 2kg", null, 1, "summer", "aaaaa", 0, null, 0, null, 50000, 52000, "../resources/images/images.jpg", 0, "contract", 0);
      list.add(vo1);
      list.add(vo2);
      list.add(vo3);
      list.add(vo4);
//      list.add(vo5);
      model.addAttribute("productList", list);
         
      String userid=(String) session.getAttribute("login_id"); 
      list = service.selectListByCart(userid);
      
      }
   
   
   // 구매 목록 (결제완료하고 배송중인 물건리스트 or 배송완료된 물건의 리스트)
   // 상품평을 줄수있음   
   @RequestMapping(value = "/buyList", method = RequestMethod.GET)
   public void buyList(HttpSession session, Model model) {
      System.out.println("buyList에옴");
            
      String userid=(String) session.getAttribute("login_id"); 
      List<ProductVO> list = service.selectListByBuyed(userid);
      logger.info("buy list:"+list.size());
      model.addAttribute("buyList", list);
      
   }
   
   // 입찰중인 목록
   @RequestMapping(value = "/biddingList", method = RequestMethod.GET)
   public void biddingList(HttpSession session, Model model) {
      System.out.println("userBiddingList에옴");
            
      String userid= (String) session.getAttribute("login_id"); 
      List<ProductVO> list = service.selectListByBidding(userid);
      logger.info("bidding list:"+list.size());
      model.addAttribute("userBiddingList", list);
      
   }
   
   // 내 상품보기 목록
   @RequestMapping(value = "/productList", method = RequestMethod.GET)
   public void productList(HttpSession session, Model model) {
      System.out.println("productList에옴");
            
      String userid= (String) session.getAttribute("login_id"); 
      List<ProductVO> list = service.selectListBySeller(userid);
      logger.info("productList:"+list.size());
      model.addAttribute("productList", list);
   }
   
   // 전체 회원 리스트   
   @RequestMapping(value="/list", method= RequestMethod.GET)
   public void list(Model model) {
      logger.info("list() 호출");
      List<UserVO> list = userService.read();
      model.addAttribute("userList", list);
      
   }
   
   // 회원정보 탭
   // 회원정보 탭, 회원상태 탭, 회원탈퇴 탭
   @RequestMapping(value = "/myInfo", method = RequestMethod.GET )
   public void myinfo(HttpSession session, Model model) {
//      UserVO vo=new UserVO("", "", "", "", "", "", null, null, null);
//      HttpSession session =  request.getSession();

      String userid= (String) session.getAttribute("login_id");
      logger.info("userid: " + userid);
 
      UserVO vo = userService.read(userid);
      model.addAttribute("vo", vo);
      logger.info("myinfo");
   }
   
   // 회원정보 수정 확인
   @RequestMapping(value = "/myInfo", method = RequestMethod.POST )
   public void update(UserVO vo) {
      logger.info("updatePOST() 호출: userid = " + vo.getId());
      logger.info(vo.getPw()+","+ vo.getPhone()+","+ vo.getEmail() +","+vo.getAddress() +"");
      
      int result = userService.update(vo);
      if (result == 1) {
         logger.info("testUpdate 성공");
      } else {
         logger.info("testUpdate 실패");
      }
   }
      
   // 회원탈퇴  세션삭제-유저삭제
   @RequestMapping(value = "/auctionOut", method = RequestMethod.GET )
   public void deleteGET(HttpServletRequest req) {
      HttpSession session=req.getSession();
      String userid= (String) session.getAttribute("login_id");
      logger.info("deleteGET() 호출: userid = " + userid);
      
      session.removeAttribute("login_id");
      session.invalidate();
      int result = userService.delete(userid);
      if (result == 1) {
         logger.info("testDelete 성공");
         
      } else {
         logger.info("testDelete 실패");
      }
   }
   
   // 주문리스트 폼
   @RequestMapping(value = "/orderList", method = RequestMethod.GET )
   public void orderListGET() {
      
   }
   
   // 나의 상품평 폼
   @RequestMapping(value = "/registerReview", method = RequestMethod.GET )
   public void registerReviewGET() {
      
   }
   
   // 로그인 폼
   @RequestMapping(value = "/login", method = RequestMethod.GET )
   public void loginGET() {
      
   }
   
   // 로그인 확인 submit 하면 LoginInterceptor가 가로챔
   @RequestMapping(value = "/login-post", method = RequestMethod.POST )
   public void loginPOST(UserVO vo, Model model) {
      logger.info(vo.getId() + ","
            + vo.getPw());
      UserVO result = userService.loginCheck(vo);
      model.addAttribute("login_result", result);
      logger.info("result : " + result);
   }
   // 로그아웃
   @RequestMapping(value="/logout", method = RequestMethod.GET)
   public String logout(HttpServletRequest req) {
      logger.info("logout() 호출");
      
      HttpSession session = req.getSession();
      session.removeAttribute("login_id");
      session.invalidate();
      
      return "/main";
   }
   
   // 이동 페이지
   @RequestMapping(value = "/thankyou", method = RequestMethod.GET )
   public void thankyou() {
      
   }
   
   // 회원가입 폼
   @RequestMapping(value = "/registerUser", method = RequestMethod.GET )
   public void registerUserGET() {
      
   }
   
   //회원가입 확인
   @RequestMapping(value = "/registerUser", method = RequestMethod.POST )
   public String registerUserPOST(UserVO vo) {
      logger.info("registerUserPOST() 호출");
      int result = userService.create(vo);
      logger.info("회원가입Insert: result =" + result);
      if (result == 1) {
         logger.info("회원가입Insert 성공");
      } else {
         logger.info("회원가입Insert 실패");
      }
      return "/user/thankyou";
   }
   
   // 패스워드 체크
   @RequestMapping(value = "/checking-id", method = RequestMethod.POST )
   public void isExitingPw(String pw, UserVO vo, HttpServletResponse res) {
      
            
      if (userService.isExitingId(pw)) {
         // DB에 패스워드가 존재하는 경우
         try {
            res.getWriter().write("invalid");
         } catch (Exception e) {
            e.printStackTrace();
         }
         logger.info("invalid");
         
      } else {
         // DB에 패스워드가 없는 경우
         try {
            res.getWriter().write("valid");
         } catch (Exception e) {
            e.printStackTrace();
         }
         logger.info("valid");

      }

   }
   
   // 아이디 체크
   @RequestMapping(value = "/checking-id", method = RequestMethod.GET )
   public void isExitingId(String id, UserVO vo, HttpServletResponse res) {
      
            
      if (userService.isExitingId(id)) {
         // DB에 아이디가 존재하는 경우
         try {
            res.getWriter().write("invalid");
         } catch (Exception e) {
            e.printStackTrace();
         }
         logger.info("invalid");
         
      } else {
         // DB에 아이디가 없는 경우
         try {
            res.getWriter().write("valid");
         } catch (Exception e) {
            e.printStackTrace();
         }
         logger.info("valid");

      }

   }
   

   
}